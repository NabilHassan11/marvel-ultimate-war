package exceptions;


@SuppressWarnings("serial")
public class AbilityUseException extends GameActionException {

	public AbilityUseException() {
		super();

	}

	public AbilityUseException(String s) {
		super(s);

	}

}
